const Home = () => {
  return (
    <div className="text-center mt-5">
      <h1>Welcome to the Star Wars API Navigator</h1>
    </div>
  );
};

export default Home;
