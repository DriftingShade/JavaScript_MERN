import React from "react";
import FormComponent from "./components/FormComponent";

const App = () => {
  return (
    <div>
      <h1>Reactive Forms</h1>
      <FormComponent />
    </div>
  );
};

export default App;
