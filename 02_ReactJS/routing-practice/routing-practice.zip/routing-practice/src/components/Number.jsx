

const Number = ({ number }) => {
  return <h1>The number is: {number}</h1>;
};

export default Number;
