const Word = ({ word }) => {
    return <h1>The word is: {word}</h1>;
  };
  
  export default Word;