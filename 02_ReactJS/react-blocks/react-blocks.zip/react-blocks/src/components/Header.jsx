import React from 'react';

const Header = () => {
    return <div className="header">Header</div>;
};

export default Header;
