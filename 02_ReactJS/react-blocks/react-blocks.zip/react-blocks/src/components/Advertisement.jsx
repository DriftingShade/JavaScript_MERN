import React from 'react';

const Advertisement = () => {
    return <div className="advertisement">Advertisement</div>;
};

export default Advertisement;
