import React from 'react';

const Subcontent = () => {
    return <div className="subcontent">Subcontent</div>;
};

export default Subcontent;
