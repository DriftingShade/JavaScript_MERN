import React from 'react';

const Navigation = () => {
    return <div className="navigation">Navigation</div>;
};

export default Navigation;
